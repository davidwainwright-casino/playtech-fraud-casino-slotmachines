<?php

namespace Laravel\Nova\Metrics;

class Table extends Metric
{
    /**
     * The element's component.
     *
     * @var string
     */
    public $component = 'table-metric';
}
