<?php

namespace Laravel\Nova\Http\Requests;

class ResourceUpdateOrUpdateAttachedRequest extends NovaRequest
{
    //
}
