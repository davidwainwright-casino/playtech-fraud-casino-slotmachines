<?php

namespace Laravel\Nova\Http\Requests;

class ResourceDetailRequest extends NovaRequest
{
    //
}
