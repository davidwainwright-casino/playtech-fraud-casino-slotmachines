<?php

namespace Laravel\Nova\Fields\Filters;

class BooleanFilter extends Filter
{
    /**
     * The filter's component.
     *
     * @var string
     */
    public $component = 'boolean-field';
}
