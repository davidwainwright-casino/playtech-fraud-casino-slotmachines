<?php

namespace Laravel\Nova\Fields\Filters;

class SelectFilter extends Filter
{
    /**
     * The filter's component.
     *
     * @var string
     */
    public $component = 'select-field';
}
