<?php

namespace Laravel\Nova\Fields\Filters;

class MultiSelectFilter extends Filter
{
    /**
     * The filter's component.
     *
     * @var string
     */
    public $component = 'multi-select-field';
}
